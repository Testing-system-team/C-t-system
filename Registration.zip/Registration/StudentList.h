#pragma once
#include"Header.h"
#include "StudentInfo.h"
class StudentList
{
	std::vector<StudentInfo> students;
public:
	void AddSudent(const StudentInfo& s);
	bool LoginExist(std::string login)const;
	void display()const;
	void displayByLogin(std::string& login)const;
	std::vector<StudentInfo> GetStudents()const;
	std::vector<StudentInfo>::const_iterator begin() const;
	std::vector<StudentInfo>::const_iterator end() const;

};

