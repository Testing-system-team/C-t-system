#pragma once
#include"Header.h"
#include "DataManage.h"
#include "StudentList.h"
class AdminInfo
{
	std::string login;
	std::string password;
	
public:
	AdminInfo();
	AdminInfo(std::string login, std::string password);
	std::string GetLogin()const;
	bool CheckLogin(AdminInfo a, std::string login);
	std::string GetPassword()const;
	bool CheckPassword(AdminInfo a, std::string password);
	void CreateAdmin();
	void Display()const;
	static AdminInfo loadData();
	operator pt::ptree()const;
};

