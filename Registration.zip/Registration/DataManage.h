#pragma once
#include "Header.h"
#include "StudentList.h"
#include "StudentInfo.h"
class DataManage
{
	StudentList catalog;
	std::string fileName;
public:

	DataManage();
	void display()const;
	void displayByName(std::string login) const;
	void loadData();
	//bool LoginExist(std::string login)const;
	bool FindLogin(std::string login)const;
	bool CheckPassword(std::string password)const;
	void safeToFile()const;
	StudentList& getCatalog();
};

