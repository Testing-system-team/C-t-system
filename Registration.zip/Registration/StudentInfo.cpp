#include "StudentInfo.h"

StudentInfo::StudentInfo() = default;

StudentInfo::StudentInfo(std::string name, std::string surname, std::string patronymic, std::string adress, std::string phoneNumber, std::string login, std::string password)
:name(name),surname(surname),patronymic(patronymic),adress(adress),phoneNumber(phoneNumber),login(login),password(password){}

void StudentInfo::display() const
{
	std::cout << name << "\n";
	std::cout << surname << "\n";
	std::cout << patronymic << "\n";
	std::cout << adress << "\n";
	std::cout << phoneNumber << "\n";
	std::cout << login << "\n";
	std::cout << password << "\n";
}
std::string StudentInfo::GetName() const
{
	return name;
}
std::string StudentInfo::GetLogin() const
{
	return login;
}
std::string StudentInfo::GetPassword() const
{
	return password;
}
StudentInfo::operator pt::ptree()const
{
	pt::ptree stTags;
	stTags.put("name", name);
	stTags.put("surname", surname);
	stTags.put("patronymic", patronymic);
	stTags.put("adress", adress);
	stTags.put("phoneNumber", phoneNumber);
	stTags.put("login", login);
	stTags.put("password", password);
	return stTags;
}
//void StudentInfo::safeToFile(const StudentInfo& s)
//{
//	pt::ptree tree;
//
//	tree.add("List.students.student.name", s.name);
//	tree.add("List.students.student.surname", s.surname);
//	tree.add("List.students.student.patronymic", s.patronymic);
//	tree.add("List.students.student.adress", s.adress);
//	tree.add("List.students.student.phoneNumber", s.phoneNumber);
//	tree.add("List.students.student.login", s.login);
//	tree.add("List.students.student.password", s.password);
//
//	write_xml("student.xml", tree);
//	
//}