#include"Header.h"
#include "StudentList.h"
#include"StudentInfo.h"
void StudentList::AddSudent(const StudentInfo& s)
{
	students.push_back(s);
	
}
bool StudentList::LoginExist(std::string login)const
{
	for (auto iter = students.begin(); iter != students.end(); iter++)
	{
		if (login == iter->GetLogin())
			return true;
	}
	return false;
}
void StudentList::display()const
{
	if(students.size()!=0)
	{
		std::for_each(students.begin(), students.end(), [](const StudentInfo& s) {
			std::cout << "\n--------\n";
			s.display();
			});
	}
}
void StudentList::displayByLogin(std::string& login)const
{
	if (students.size() != 0)
	{
		std::for_each(students.begin(), students.end(), [login](const StudentInfo& s) {
			if(s.GetLogin()==login)
				s.display();
			
		});
	}
}
std::vector<StudentInfo> StudentList::GetStudents() const
{
	return students;
}
std::vector<StudentInfo>::const_iterator StudentList::begin() const
{
	return students.begin();
}

std::vector<StudentInfo>::const_iterator StudentList::end() const
{
	return students.end();
}
