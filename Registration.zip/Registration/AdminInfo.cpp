#include "AdminInfo.h"
#include"DataManage.h"
AdminInfo::AdminInfo() = default;
AdminInfo::AdminInfo(std::string login, std::string password)
	:login(login),password(password){}

std::string AdminInfo::GetLogin() const
{
	return login;
}

bool AdminInfo::CheckLogin(AdminInfo a,std::string login)
{
	if (a.GetLogin() == login)
		return true;
	return false;
}

void AdminInfo::CreateAdmin()
{
	pt::ptree tree;
	do
	{
		std::cout << "\nEnter login for Admin-> ";
		std::getline(std::cin, login);

		std::cout << "\nEnter password for Admin-> ";
		std::getline(std::cin, password);
	} while (login == "" || password == "");
	AdminInfo newAdmin(login, password);
	tree.add_child("List.admin", newAdmin);
	
	pt::write_xml("Admin.xml", tree);
}


void AdminInfo::Display() const
{
	std::cout << login << "\n" << password << "\n";
}

AdminInfo AdminInfo::loadData()
{
	pt::ptree tree;
	//2 ������� ���� �� ��������� ����� � ������ ������
	pt::read_xml("Admin.xml", tree);


	BOOST_FOREACH(auto & admins, tree.get_child("List"))
	{
	
		std::string login = admins.second.get<std::string>("login");
		std::string password = admins.second.get<std::string>("password");
		

		
		AdminInfo a(login, password);
		if(login==""||password=="")
		{
			std::cout << "\nYou need to register";
			a.CreateAdmin();
			login = admins.second.get<std::string>("login");
			password = admins.second.get<std::string>("password");
		}
		return a;
	}


}
AdminInfo::operator pt::ptree()const
{
	pt::ptree stTags;
	
	stTags.put("login", login);
	stTags.put("password", password);
	return stTags;
}

std::string AdminInfo::GetPassword() const
{
	return password;
}

bool AdminInfo::CheckPassword(AdminInfo a, std::string password)
{
	if (a.GetPassword() == password)
		return true;
	return false;
}
