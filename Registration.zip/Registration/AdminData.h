#pragma once
#include"Header.h"
#include"AdminInfo.h"
class AdminData
{
	std::vector<AdminInfo> admin;
public:

	//static AdminInfo loadData();
	//void display(std::vector<AdminInfo>admin)const;
	//std::vector<AdminInfo>::const_iterator begin() const;
	//std::vector<AdminInfo>::const_iterator end() const;
};

