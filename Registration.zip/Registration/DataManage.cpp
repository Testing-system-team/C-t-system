#include"Header.h"
#include "DataManage.h"
#include"StudentInfo.h"
#include"StudentList.h"
DataManage::DataManage()
{
	fileName = "student.xml";
}

void DataManage::display() const
{

	catalog.display();
}
void DataManage::displayByName(std::string login) const
{

	catalog.displayByLogin(login);
}

void DataManage::loadData()
{
	pt::ptree tree;
	
	pt::read_xml(fileName, tree);


	BOOST_FOREACH(auto& student,tree.get_child("List.students"))
	{
		std::string name = student.second.get<std::string>("name");
		std::string surname = student.second.get<std::string>("surname");
		std::string patronymic = student.second.get<std::string>("patronymic");
		std::string adress = student.second.get<std::string>("adress");
		std::string phone = student.second.get<std::string>("phoneNumber");
		std::string login = student.second.get<std::string>("login");
		std::string password = student.second.get<std::string>("password");

		catalog.AddSudent(StudentInfo(name, surname, patronymic, adress, phone, login, password));

	}
}

bool DataManage::FindLogin(std::string login) const
{
	pt::ptree tree;
	pt::read_xml(fileName, tree);
	BOOST_FOREACH(auto & student, tree.get_child("List.students"))
	{

		if (student.second.get<std::string>("login") == login)
			return true;
	}
	return false;
	
}

bool DataManage::CheckPassword(std::string password) const
{
	pt::ptree tree;
	pt::read_xml(fileName, tree);
	BOOST_FOREACH(auto & student, tree.get_child("List.students"))
	{

		if (student.second.get<std::string>("password") == password)
			return true;
	}
	return false;
}

void DataManage::safeToFile()const
{
	pt::ptree tree;
	

	for (auto student : catalog)
	{
		tree.add_child("List.students.student", student);
	}

	pt::write_xml(fileName, tree);
}

StudentList& DataManage::getCatalog()
{
	return catalog;
}
