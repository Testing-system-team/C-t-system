#pragma once
#include "Header.h"
class StudentInfo
{
	std::string name;
	std::string surname;
	std::string patronymic;
	std::string adress;
	std::string phoneNumber;
	std::string login;
	std::string password;
public:
	StudentInfo();
	StudentInfo(std::string name,std::string surname,std::string patronymic,std::string adress,std::string phoneNumber,std::string login,std::string password);
	void display()const;
	std::string GetName()const;
	std::string GetLogin()const;
	std::string GetPassword()const;
	operator pt::ptree()const;
};

