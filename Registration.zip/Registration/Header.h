#pragma once
#include<iostream>
#include<string>
#include<vector>
#include<algorithm>
#include<memory>
#include <boost/property_tree/ptree.hpp>
#include <boost/property_tree/xml_parser.hpp>
#include <boost/foreach.hpp>
#include <Windows.h>
namespace pt = boost::property_tree;