﻿#include "Header.h"
#include"StudentInfo.h"
#include"StudentList.h"
#include"DataManage.h"
#include"AdminInfo.h"


int main()
{
	auto managerPtr = std::make_unique<DataManage>();
	managerPtr->loadData();
	int person = 0;
	std::cout << "Enter 1 if you are a Student\nEnter 2 if you are the Admin\n";
	std::cin >> person;
	std::cin.ignore();
	if (person == 1)
	{
		std::string name;
		std::string surname;
		std::string patronymic;
		std::string adress;
		std::string phone;
		std::string login;
		std::string password;
		

		int mistake = 1;
		int choice = 0;

		std::cout << "Enter 1 if you are registered\nEnter 2 if you want to register\n->";
		std::cin >> choice;
		if (choice != 1 && choice != 2)
		{
			do
			{
				std::cout << "\nThis choice is not available\n";
				std::cout << "Enter 1 if you are registered\nEnter 2 if you want to register\n->";
				std::cin >> choice;
			} while (choice != 1 && choice != 2);
		}
		std::cin.ignore();
		if (choice == 1)
		{
			while (mistake != 0)
			{
				//std::cin.ignore();
				std::cout << "\nlogin-> ";
				std::getline(std::cin, login);
				if (managerPtr->FindLogin(login))
				{
					std::cout << "\nLogin exist\n";
					std::cout << "\npassword-> ";
					std::getline(std::cin, password);
					if (managerPtr->CheckPassword(password) == true)
					{
						std::cout << "You have been successfully authorised\n";
						managerPtr->displayByName(login);
						mistake--;

					}
					else
					{
						std::cout << "Password is not correct\n";
						std::cout << "Enter login and password again\n";
					}
				}
				else
				{

					std::cout << "\nYou need to register";
					//std::cin.ignore();
					choice++;
					mistake--;
				}
			}
		}
		if (choice == 2)
		{

			std::cout << "\nname-> ";
			std::getline(std::cin, name);
			std::cout << "\nsurname-> ";
			std::getline(std::cin, surname);
			std::cout << "\npatronymic-> ";
			std::getline(std::cin, patronymic);
			std::cout << "\nadress-> ";
			std::getline(std::cin, adress);
			std::cout << "\nphone-> ";
			std::getline(std::cin, phone);
			std::cout << "\nlogin-> ";
			std::getline(std::cin, login);
			std::cout << managerPtr->FindLogin(login) << "\n";

			if (managerPtr->FindLogin(login))
			{
				
				while (managerPtr->FindLogin(login))
				{
					std::cout << "\nthis login already exist, choose another one-> ";
					std::getline(std::cin, login);
				}
			}
			std::cout << "\npassword-> ";
			std::getline(std::cin, password);
			managerPtr->getCatalog().AddSudent(StudentInfo(name, surname, patronymic, adress, phone, login, password));
			managerPtr->displayByName(login);
			managerPtr->safeToFile();
		}
		
	}
	else if(person==2)
	{

		AdminInfo admin;
		admin=admin.loadData();
		std::cout << "Log in: \n";
		std::string login;
		std::string password;
		std::cout << "Enter login of admin-> ";
		std::getline(std::cin, login);
		if(!admin.CheckLogin(admin, login))
		{
			while(!admin.CheckLogin(admin, login))
			{
				std::cout << "\nLogin was not correct";
				std::cout << "\nEnter login again->";
				std::getline(std::cin, login);
			
			}
			
		}
		std::cout << "Enter password -> ";
		std::getline(std::cin, password);
		if (!admin.CheckPassword(admin, password))
		{
			while (!admin.CheckPassword(admin, password))
			{
				std::cout << "\nPassword was not correct";
				std::cout << "\nEnter password again->";
				std::getline(std::cin, password);

			}

		}
		std::cout << "\nYou have been successfully loged in\n";
		//admin.Display();
		std::cout<<"\nYour Students:\n";
		managerPtr->display();
	}

	managerPtr.reset();
}
