#pragma once
class AdminManage
{
};

